<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Organization extends Model
{
    protected $table = 'organizations';
    protected $fillable = [
        'title',
        'phone',
        'country',
        'city',
        'street',
        'house',
        'email',
        'site',
        'status',
    ];
}
