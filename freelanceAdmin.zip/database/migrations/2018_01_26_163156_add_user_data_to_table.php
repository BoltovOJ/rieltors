<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddUserDataToTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('phone_number', 15)->nullable();
            $table->string('mobile', 15)->nullable();
            $table->string('country', 25)->nullable();
            $table->string('city', 15)->nullable();
            $table->string('street', 30)->nullable();
            $table->string('house', 3)->nullable();
            $table->string('additional_address', 50)->nullable();
            $table->string('about', 400)->nullable();
            $table->string('avatar')->nullable();
            $table->boolean('newsletter')->nullable();
            $table->boolean('is_admin')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('phone_number');
            $table->dropColumn('work_phone_number');
            $table->dropColumn('country');
            $table->dropColumn('city');
            $table->dropColumn('street');
            $table->dropColumn('house');
            $table->dropColumn('additional_address');
            $table->dropColumn('about');
            $table->dropColumn('avatar');
            $table->dropColumn('newsletter');
            $table->dropColumn('is_admin');
        });
    }
}
