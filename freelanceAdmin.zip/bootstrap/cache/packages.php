<?php return array (
  'adminarchitect/core' => 
  array (
    'providers' => 
    array (
      0 => 'Terranet\\Administrator\\ServiceProvider',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravelcollective/html' => 
  array (
    'providers' => 
    array (
      0 => 'Collective\\Html\\HtmlServiceProvider',
    ),
    'aliases' => 
    array (
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
    ),
  ),
  'terranet/localizer' => 
  array (
    'providers' => 
    array (
      0 => 'Terranet\\Localizer\\ServiceProvider',
    ),
  ),
  'terranet/translatable' => 
  array (
    'providers' => 
    array (
      0 => 'Terranet\\Translatable\\TranslatableServiceProvider',
    ),
  ),
);