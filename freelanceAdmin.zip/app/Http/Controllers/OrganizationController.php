<?php

namespace App\Http\Controllers;

use App\Organization;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;


class OrganizationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function addPage()
    {
        return view('user.organization.add');
    }

    public function addHandler(Request $request)
    {
        function getMessageAboutSize($name, $min, $max)
        {
            return 'Длинна поля ' . $name . ' должна быть от ' . $min . ' до ' . $max . ' символов.';
        }

        function getMessageAboutType($name, $type)
        {
            return 'Поле ' . $name . ' должно быть ' . $type . '.';
        }

        function getMessageAboutRequired($name)
        {
            return 'Поле ' . $name . ' обязательно для заполнения.';
        }

        $validator = Validator::make($request->all(), [
            'title' => 'required|min:2|max:255',
            'phone' => 'required|digits_between:6,15',
            'country' => 'required|min:2|max:25|string',
            'city' => 'required|min:2|max:15|string',
            'street' => 'required|min:2|max:30|string',
            'house' => 'required|digits_between:0,3',
            'email' => 'required|string|email|max:255',
            'website' => 'required|url',
        ], [
            'title.required' => getMessageAboutRequired('название'),

            'phone.digits_between' => 'Введён неправильный номер телефона.',
            'phone.required' => getMessageAboutRequired('номер телефона'),

            'country.string' => getMessageAboutType('государство', 'строкой'),
            'country.max' => getMessageAboutSize('государство', 2, 25),
            'country.required' => getMessageAboutRequired('государство'),

            'city.string' => getMessageAboutType('город', 'строкой'),
            'city.max' => getMessageAboutSize('город', 2, 15),
            'city.required' => getMessageAboutRequired('город'),

            'street.string' => getMessageAboutType('улица', 'строкой'),
            'street.max' => getMessageAboutSize('улица', 2, 30),
            'street.required' => getMessageAboutRequired('улица'),

            'house.digits_between' => getMessageAboutType('дом', 'числом'),
            'house.required' => getMessageAboutRequired('дом'),

            'website.required' => getMessageAboutRequired('веб сайт'),
            'website.гкд' => 'Поле веб сайт имеет ошибочный формат.',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withInput()->withErrors($validator->errors());
        }

        $organization = new Organization();

        $organization->title = $request->get('title');
        $organization->phone = $request->get('phone');
        $organization->country = $request->get('country');
        $organization->city = $request->get('city');
        $organization->street = $request->get('street');
        $organization->house = $request->get('house');
        $organization->email = $request->get('email');
        $organization->site = $request->get('website');
        $organization->status = 1;

        $organization->save();
        return redirect()->back();
    }
}

