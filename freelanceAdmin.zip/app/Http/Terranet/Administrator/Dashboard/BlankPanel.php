<?php

namespace App\Http\Terranet\Administrator\Dashboard;

use Terranet\Administrator\Dashboard\Panels\BlankPanel as CoreBlankPanel;

class BlankPanel extends CoreBlankPanel
{
    //
}
