<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddFieldsToOrganizationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('organizations', function (Blueprint $table) {
            $table->string('title', 40)->nullable();
            $table->string('country', 25)->nullable();
            $table->string('city', 15)->nullable();
            $table->string('house', 3)->nullable();
            $table->string('street', 30)->nullable();
            $table->string('phone', 15)->nullable();
            $table->string('email')->nullable();
            $table->string('site')->nullable();
            $table->string('services')->nullable();
            $table->string('photos')->nullable();
            $table->string('work_time')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('organizations', function (Blueprint $table) {
            $table->dropColumn('title');
            $table->dropColumn('country');
            $table->dropColumn('city');
            $table->dropColumn('house');
            $table->dropColumn('street');
            $table->dropColumn('phone');
            $table->dropColumn('email');
            $table->dropColumn('site');
            $table->dropColumn('services');
            $table->dropColumn('photos');
            $table->dropColumn('work_time');
        });
    }
}
