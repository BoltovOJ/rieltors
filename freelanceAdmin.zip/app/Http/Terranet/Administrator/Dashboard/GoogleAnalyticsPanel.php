<?php

namespace App\Http\Terranet\Administrator\Dashboard;

use Terranet\Administrator\Dashboard\Panels\GoogleAnalyticsPanel as CoreGoogleAnalyticsPanel;

class GoogleAnalyticsPanel extends CoreGoogleAnalyticsPanel
{
    //
}