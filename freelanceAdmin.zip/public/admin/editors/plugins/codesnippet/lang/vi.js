﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("codesnippet","vi",{button:"Chèn đoạn mã",codeContents:"Nội dung mã",emptySnippetError:"Một đoạn mã không thể để trống.",language:"Ngôn ngữ",title:"Đoạn mã",pathName:"mã dính"});