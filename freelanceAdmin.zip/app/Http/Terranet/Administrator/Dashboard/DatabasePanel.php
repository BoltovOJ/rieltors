<?php

namespace App\Http\Terranet\Administrator\Dashboard;

use Terranet\Administrator\Dashboard\Panels\DatabasePanel as CoreDatabasePanel;

class DatabasePanel extends CoreDatabasePanel
{
    //
}
