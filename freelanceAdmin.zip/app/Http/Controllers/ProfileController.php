<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{

    public function showChangePasswordForm()
    {
        return view('auth.password', [
            'message' => Session::get('message')
        ]);
    }

    public function username()
    {
        return 'email';
    }

    protected function guard()
    {
        return Auth::guard();
    }

    protected function messageIncorrectCurrentPassword()
    {
        return trans('auth.incorrect_current_password');
    }

    protected function messagePasswordChanged()
    {
        return trans('auth.password_changed');
    }

    function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'password_current' => 'required',
            'password_new' => 'required|min:6|confirmed',
            'password_new_confirmation' => 'required'
        ], [
            'password_new.min' => 'Длинна нового пороля должна быть от 6 символов',
            'password_new.confirmed' => 'Новые пароли не совпадают.',
            'password_current.required' => $this->getMessageAboutRequired('Старый пароль'),
            'password_new.required' => $this->getMessageAboutRequired('Новый пароль'),
            'password_new_confirmation.required' => $this->getMessageAboutRequired('Подтвердите пароль'),
        ]);
        $validator->after(function ($validator) use ($request) {
            if (!$this->guard()->validate([
                $this->username() => Auth::user()->getAttribute($this->username()),
                'password' => $request->get('password_current')
            ])
            ) {
                $validator->errors()->add('current_password', 'Проверьте текущий пароль.');
            }
        });
        if ($validator->fails()) {
            return redirect()->back()->withInput()->withErrors($validator->errors());
        }
        $user = $this->guard()->user();
        $user->password = Hash::make($request->get('password_new'));
        $user->save();
        Session::flash('message', $this->messagePasswordChanged());
        return redirect()->back();
    }

    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index()
    {
        return view('user.profile.profile');
    }


    private function getMessageAboutRequired($name)
    {
        return 'Поле ' . $name . ' обязательно для заполнения.';
    }


    public function update(Request $request)
    {
        function getMessageAboutSize($name, $min, $max)
        {
            return 'Длинна поля ' . $name . ' должна быть от ' . $min . ' до ' . $max . ' символов.';
        }

        function getMessageAboutType($name, $type)
        {
            return 'Поле ' . $name . ' должно быть ' . $type . '.';
        }


        $validator = Validator::make($request->all(), [
            'about-me' => 'required|string|min:10|max:400',
            'phone' => 'required|digits_between:6,15',
            'mobile' => 'nullable|digits_between:6,15',
            'country' => 'nullable|min:2|max:25|string',
            'city' => 'nullable|min:2|max:15|string',
            'street' => 'nullable|min:2|max:30|string',
            'house' => 'nullable|digits_between:0,3',
            'additional-address' => 'nullable|string|min:10|max:50',
        ], [
            'phone.digits_between' => 'Введён неправильный номер телефона.',
            'phone.required' => $this->getMessageAboutRequired('номер телефона'),
            'mobile.digits_between' => 'Введён неправильный рабочий номер.',

            'country.string' => getMessageAboutType('страна', 'строкой'),
            'country.max' => getMessageAboutSize('страна', 2, 25),

            'city.string' => getMessageAboutType('город', 'строкой'),
            'city.max' => getMessageAboutSize('город', 2, 15),

            'street.string' => getMessageAboutType('улица', 'строкой'),
            'street.max' => getMessageAboutSize('улица', 2, 30),

            'house.digits_between' => getMessageAboutType('дом', 'числом'),

            'additional-address.string' => getMessageAboutType('дополнительный адрес', 'строкой'),
            'additional-address.min' => getMessageAboutSize('дополнительный адрес', 10, 50),
            'additional-address.max' => getMessageAboutSize('дополнительный адрес', 10, 50),

            'about-me.required' => $this->getMessageAboutRequired('расскажите о себе'),
            'about-me.string' => getMessageAboutType('расскажите о себе', 'строкой'),
            'about-me.min' => getMessageAboutSize('расскажите о себе', 10, 400),
            'about-me.max' => getMessageAboutSize('расскажите о себе', 10, 400),
        ]);

        if ($validator->errors()->has('about-me') or $validator->errors()->has('phone')) {
            return redirect()->back()->withInput()->withErrors($validator->errors());
        }

        $user = $this->guard()->user();
        $user->mobile = $request->get('mobile');
        $user->phone_number = $request->get('phone');
        $user->country = $request->get('country');
        $user->city = $request->get('city');
        $user->street = $request->get('street');
        $user->house = $request->get('house');
        $user->additional_address = $request->get('additional-address');
        $user->about = $request->get('about-me');
        $user->save();

        return redirect()->back();
    }
}

